import flet as ft


def main(page: ft.Page):
    page.title = "Kandjimbi Eliakim | Portfolio"
    page.theme_mode = ft.ThemeMode.DARK
    page.scroll = ft.ScrollMode.AUTO
    page.padding = 0
    page.bgcolor = "#0f0f0f"

    # ---------------- URL HELPER ----------------
    async def open_url(url):
        await page.launch_url(url)

    # ---------------- NAVIGATION ----------------
    def go_to(section):
        print(f"Navigate to: {section}")

    # ---------------- BLOG CARD ----------------
    def blog_card(date, title, excerpt, url="https://github.com/akim12"):
        return ft.Container(
            content=ft.Column(
                [
                    ft.Text(
                        date,
                        size=12,
                        color="#6C63FF",
                        weight=ft.FontWeight.BOLD,
                    ),
                    ft.Text(
                        title,
                        size=18,
                        weight=ft.FontWeight.BOLD,
                    ),
                    ft.Text(
                        excerpt,
                        size=14,
                        color="#bbbbbb",
                        max_lines=2,
                    ),
                    ft.TextButton(
                        "Read Full Post",
                        on_click=lambda e: page.run_task(
                            open_url, url
                        ),
                    ),
                ],
                spacing=10,
            ),
            padding=20,
            bgcolor="#1a1a1a",
            border_radius=12,
            width=300,
        )

    # ---------------- NAVBAR ----------------
    navbar = ft.Container(
        content=ft.Row(
            [
                ft.Text(
                    "My Portfolio",
                    size=22,
                    weight=ft.FontWeight.BOLD,
                ),
                ft.Row(
                    [
                        ft.TextButton(
                            "Home",
                            on_click=lambda e: go_to("home"),
                        ),
                        ft.TextButton(
                            "Projects",
                            on_click=lambda e: go_to("projects"),
                        ),
                        ft.TextButton(
                            "Blog",
                            on_click=lambda e: go_to("blog"),
                        ),
                        ft.TextButton(
                            "LinkedIn",
                            on_click=lambda e: page.run_task(
                                open_url,
                                "https://www.linkedin.com/in/eliakim-kandjimbi-9b1a4b1b2/",
                            ),
                        ),
                        ft.ElevatedButton(
                            "GitHub",
                            icon=ft.Icons.CODE,
                            on_click=lambda e: page.run_task(
                                open_url,
                                "https://github.com/akim12",
                            ),
                        ),
                    ],
                    spacing=10,
                ),
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        ),
        padding=20,
        bgcolor="#121212",
    )

    # ---------------- HERO ----------------
    hero = ft.Container(
        content=ft.Column(
            [
                ft.CircleAvatar(
                    foreground_image_src="profile.jpeg",
                    radius=90,
                ),
                ft.Text(
                    "👋 Hi, I'm",
                    size=20,
                    color="grey",
                ),
                ft.Text(
                    "Kandjimbi Eliakim",
                    size=60,
                    weight=ft.FontWeight.BOLD,
                ),
                ft.Text(
                    "I build clean and modern apps using Python & Flet.",
                    size=18,
                    color="#aaaaaa",
                    text_align=ft.TextAlign.CENTER,
                ),
                ft.Row(
                    [
                        ft.ElevatedButton(
                            "View Projects",
                            on_click=lambda e: go_to("projects"),
                            style=ft.ButtonStyle(
                                bgcolor="#6C63FF",
                                color="white",
                            ),
                        ),
                        ft.OutlinedButton(
                            "Contact Me",
                            on_click=lambda e: go_to("contact"),
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=15,
        ),
        alignment=ft.alignment.Alignment(0, 0),
        padding=ft.Padding(left=20, top=0, right=20, bottom=0
        ),
    )

    # ---------------- SKILLS ----------------
    skills = ft.Container(
        content=ft.Column(
            [
                ft.Text(
                    "Skills",
                    size=32,
                    weight=ft.FontWeight.BOLD,
                ),
                ft.Row(
                    [
                        ft.Chip(label=ft.Text("Python")),
                        ft.Chip(label=ft.Text("Flet")),
                        ft.Chip(label=ft.Text("UI/UX")),
                        ft.Chip(label=ft.Text("GitHub")),
                        ft.Chip(label=ft.Text("JavaScript")),
                        ft.Chip(label=ft.Text("MATLAB")),
                    ],
                    wrap=True,
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20,
        ),
        padding=60,
    )

    # ---------------- PROJECT CARD ----------------
    def project_card(title, desc, url):
        return ft.Container(
            content=ft.Column(
                [
                    ft.Text(
                        title,
                        size=20,
                        weight=ft.FontWeight.BOLD,
                    ),
                    ft.Text(
                        desc,
                        color="#bbbbbb",
                    ),
                    ft.TextButton(
                        "View Project",
                        on_click=lambda e: page.run_task(
                            open_url,
                            url,
                        ),
                    ),
                ]
            ),
            padding=20,
            border_radius=15,
            bgcolor="#1a1a1a",
            width=280,
        )

    def certificate_card(title, image):
        return ft.Container(
            width=250,
            bgcolor="#1a1a1a",
            border_radius=12,
            padding=15,
            content=ft.Column(
                [
                    ft.Image(
                        src=image,
                        height=140,
                        fit=ft.ImageFit.CONTAIN,
                    ),
                    ft.Text(
                        title,
                        text_align=ft.TextAlign.CENTER,
                        weight=ft.FontWeight.BOLD,
                    ),
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=10,
            ),
        )

    # ---------------- PROJECTS ----------------
    projects = ft.Container(
        content=ft.Column(
            [
                ft.Text(
                    "Projects",
                    size=32,
                    weight=ft.FontWeight.BOLD,
                ),
                ft.Row(
                    [
                        project_card(
                            "Portfolio App",
                            "Built with Flet UI",
                            "https://github.com/akim12/flet-portfolio",
                        ),
                        project_card(
                            "Task Manager",
                            "Productivity app",
                            "https://github.com/akim12",
                        ),
                        project_card(
                            "Coming Soon",
                            "More coming 🚀",
                            "https://github.com/akim12",
                        ),
                    ],
                    wrap=True,
                    spacing=20,
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20,
        ),
        padding=60,
    )

    # ---------------- BLOG ----------------
    blog_section = ft.Container(
        content=ft.Column(
            [
                ft.Text(
                    "My Journey",
                    size=32,
                    weight=ft.FontWeight.BOLD,
                ),
                ft.Text(
                    "Insights on Python, Flet, MATLAB, and UI Design",
                    color="grey",
                ),
                ft.Row(
                    [
                        blog_card(
                            "Week 1",
                            "Project Planning & Setup",
                            "Group formation, GitHub setup, and architecture planning.",
                        ),
                        blog_card(
                            "Week 2",
                            "UI Design & Firebase Auth",
                            "Created login and registration screens.",
                        ),
                        blog_card(
                            "Week 3",
                            "Firestore Integration",
                            "Connected Firebase services and storage.",
                        ),
                    ],
                    wrap=True,
                    spacing=20,
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=30,
        ),
        padding=60,
    )
    # ---------------- CERTIFICATES ----------------
    certificates = [
       {"name": "Explore Data with MATLAB Plots", "img": "certificates/explore_data_with_matlab_plots.png"},
        {"name": "Calculations with Vectors and Matrices", "img": "certificates/calculations_with_vectors_and_matrices.png"},
        {"name": "Make and Manipulate Matrices", "img": "certificates/make_and_manipulate_matrices.png"},
        {"name": "Machine Learning Onramp", "img": "certificates/machine_learning_onramp.png"},
        {"name": "MATLAB Onramp", "img": "certificates/matlab_onramp.png"},
        {"name": "Simulink Onramp", "img": "certificates/simulink_onramp.png"},
        {"name": "Signal Preprocessing Techniques", "img": "certificates/signal_preprocessing_techniques.png"}
    ]
    # Certificate images
    cert_cards = []
    for cert in certificates:
        cert_cards.append(
            ft.Container(
                content=ft.Column([
                    ft.Text(cert["name"], size=16, weight=ft.FontWeight.BOLD, color="#9bbcff"),
                    ft.Image(src=cert["img"], width=400, height=None, fit="contain", border_radius=10),
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=5),
                padding=10, bgcolor="#0E0E0E", border_radius=12,
            )
        )

    matlab = ft.Container(
        content=ft.Column([
            ft.Text("MATLAB Achievement Hub", size=26, weight=ft.FontWeight.BOLD, color="white"),
            ft.Divider(color="white24"),
            ft.Text("✅ 7 Certificates Completed (MathWorks Learning Center)", size=14, color="#9bbcff"),
            ft.GridView(controls=cert_cards, runs_count=2, spacing=10, run_spacing=10, max_extent=450),
    
        ]),
        padding=20, bgcolor="#060606", border_radius=20,
    )

    # ---------------- CONTACT ----------------
    contact = ft.Container(
        content=ft.Column(
            [
                ft.Text(
                    "Let's Connect",
                    size=32,
                    weight=ft.FontWeight.BOLD,
                ),
                ft.ElevatedButton(
                    "Send Email",
                    style=ft.ButtonStyle(
                        bgcolor="#6C63FF",
                        color="white",
                    ),
                    on_click=lambda e: page.run_task(
                        open_url,
                        "mailto:eliakimkandjimbi@gmail.com",
                    ),
                ),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20,
        ),
        padding=60,
    )

    # ---------------- FOOTER ----------------
    footer = ft.Container(
        content=ft.Text(
            "© 2026 Kandjimbi Eliakim",
            color="grey",
        ),
        alignment=ft.alignment.Alignment(0, 0),
        padding=40,
    )

    page.add(
        navbar,
        hero,
        skills,
        matlab, ft.Container(height=15),
        projects,
        blog_section,
        contact,
        footer,
    )


ft.run(main)